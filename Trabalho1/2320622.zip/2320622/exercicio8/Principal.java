package exercicio8;

/*
Exercicio 8
Autor(es): Filipe Augusto Parreira Almeida
Data: 27/03/2023
*/

public class Principal {

   public static void main(String[] args) {
       Computador computador1 = new Computador();
       computador1.setNome("comp1").setMarca("Intel").setData(1, 1, 2001);
       System.out.println(computador1);

   }
    
}
