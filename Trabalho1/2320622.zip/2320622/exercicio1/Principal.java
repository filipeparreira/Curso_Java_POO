package exercicio1;

/*
Exercicio 1
Autor(es): Filipe Augusto Parreira Almeida
Data: 27/03/2023
*/

public class Principal {

   public static void main(String[] args) {
   
   }
    
}
