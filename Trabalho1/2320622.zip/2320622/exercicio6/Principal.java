package exercicio6;

/*
Exercicio 6
Autor(es): Filipe Augusto Parreira Almeida
Data: 27/03/2023
*/

public class Principal {

   public static void main(String[] args) {
       Estacionamento veiculo = new Estacionamento("Carro", "ABC-3687", "12:20", "13:26");
       System.out.println(veiculo.toString());
   }
    
}
